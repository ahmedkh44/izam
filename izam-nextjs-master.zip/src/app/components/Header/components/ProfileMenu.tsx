import { useState } from "react";
import { Avatar, Menu, MenuItem, Typography, Divider } from "@mui/material";

const ProfileMenu = () => {
  const [anchorEl, setAnchorEl] = useState(null);
  const open = Boolean(anchorEl);

  const handleClick = (event: any) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
      <Avatar
        sx={{ width: 40, height: 40, cursor: "pointer" }}
        src="/assets/icons/profile-avatar.png"
        alt="User Avatar"
        onClick={handleClick}
      />

      <Menu
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "right",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "right",
        }}
      >
        <MenuItem onClick={handleClose} sx={{ width: 300, }} >
          <Avatar sx={{ width: 32, height: 32, marginRight: 1 }} src="/assets/icons/profile-avatar.png" />
          <div>
            <Typography variant="subtitle1">Ahmed Amaar</Typography>
            <Typography variant="body2" color="textSecondary">
              UX UI Designer
            </Typography>
          </div>
        </MenuItem>
        <Divider />
        <MenuItem onClick={handleClose}>Setting and privacy</MenuItem>
        <MenuItem onClick={handleClose}>Language</MenuItem>
        <MenuItem onClick={handleClose}>Help</MenuItem>
        <Divider />
        <MenuItem onClick={handleClose} sx={{ color: "red" }}>
          Logout
        </MenuItem>
      </Menu>
    </>
  );
};

export default ProfileMenu;
